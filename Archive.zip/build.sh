go get github.com/gorilla/mux
go get github.com/dgrijalva/jwt-go
go get github.com/dgrijalva/jwt-go/request
go get github.com/lib/pq
go get golang.org/x/crypto/bcrypt
go build -o bin/application application.go
